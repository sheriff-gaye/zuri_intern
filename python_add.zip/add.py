

num1=float(input("Enter a number :"))
num2=float(input("Enter another number :"))

sum=int(num1+num2)

print(sum)